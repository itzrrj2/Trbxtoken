aria2c --enable-rpc --rpc-listen-all=false --rpc-allow-origin-all --daemon && python3 terabox.py
